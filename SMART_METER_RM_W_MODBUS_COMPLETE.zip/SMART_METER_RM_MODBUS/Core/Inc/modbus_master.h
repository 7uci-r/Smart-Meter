#ifndef INC_MODBUS_MASTER_H_
#define INC_MODBUS_MASTER_H_

#include "main.h"   // Include STM32 HAL and core types

/* ==================== REGISTER ADDRESSES (From Meter Manual) ==================== */
// These are the 1-based Modbus addresses for the Enersol meter.
// The Modbus master code will use 0-based addresses for the request.
#define METER_SLAVE_ID              1        // Modbus slave address of the Enersol meter
#define REG_VOLTAGE_R               3866     // R-Phase Voltage
#define REG_CURRENT_R               3868     // R-Phase Current
#define REG_ACTIVE_POWER_TOTAL      3842     // Total Active Power
#define REG_POWER_FACTOR_TOTAL      3846     // Total Power Factor
#define REG_FREQUENCY               3854     // Frequency

/*THIS ADDRESS IS WRONG*/
#define REG_ACTIVE_ENERGY_WH        3900     // Active Energy (in Wh)

// Standard Modbus function code to read holding registers
#define MODBUS_FC_READ_HOLDING_REGISTERS 0x03

// Union to easily convert between a 32-bit float and its raw bytes
typedef union {
    float f;
    uint32_t u32;
    uint8_t u8[4];
} float_converter_t;

// Modbus Master Handle structure to hold all necessary communication data
typedef struct {
    UART_HandleTypeDef *huart;
    uint8_t slave_id;
    GPIO_TypeDef* de_port;
    uint16_t de_pin;
    uint8_t tx_buffer[32]; // Buffer for outgoing Modbus requests
    uint8_t rx_buffer[32]; // Buffer for incoming Modbus responses
} Modbus_Master_Handle;

// Function prototypes
void Modbus_Master_Init(Modbus_Master_Handle* hmodbus, uint8_t slave_id,
                        UART_HandleTypeDef* huart, GPIO_TypeDef* de_port, uint16_t de_pin);

// Function to read a 32-bit float value from the meter
HAL_StatusTypeDef Modbus_Master_Read_Float(Modbus_Master_Handle* hmodbus,
                                           uint16_t reg_addr, float* result);

#endif /* INC_MODBUS_MASTER_H_ */
