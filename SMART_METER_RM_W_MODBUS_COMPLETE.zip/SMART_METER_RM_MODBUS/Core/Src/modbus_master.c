#include "modbus_master.h"
#include <string.h>
#include <math.h>
#include <stdio.h>  // for printf()

// 💡 NOTE: The CRC table is not shown for brevity, but it should be placed here
// as a static const array. The table you provided in your original file is correct.
static const uint16_t crc16_table[] = {
    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241, 0xC601, 0x06C0,
    0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440, 0xCC01, 0x0CC0, 0x0D80, 0xCD41,
    0x0F00, 0xCFC1, 0xCE81, 0x0E40, 0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0,
    0x0880, 0xC841, 0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
    0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41, 0x1400, 0xD4C1,
    0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641, 0xD201, 0x12C0, 0x1380, 0xD341,
    0x1100, 0xD1C1, 0xD081, 0x1040, 0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1,
    0xF281, 0x3240, 0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
    0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41, 0xFA01, 0x3AC0,
    0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840, 0x2800, 0xE8C1, 0xE981, 0x2940,
    0xEB01, 0x2BC0, 0x2A80, 0xEA41, 0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1,
    0xEC81, 0x2C40, 0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
    0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041, 0xA001, 0x60C0,
    0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240, 0x6600, 0xA6C1, 0xA781, 0x6740,
    0xA501, 0x65C0, 0x6480, 0xA441, 0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0,
    0x6E80, 0xAE41, 0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
    0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41, 0xBE01, 0x7EC0,
    0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40, 0xB401, 0x74C0, 0x7580, 0xB541,
    0x7700, 0xB7C1, 0xB681, 0x7640, 0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0,
    0x7080, 0xB041, 0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
    0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440, 0x9C01, 0x5CC0,
    0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40, 0x5A00, 0x9AC1, 0x9B81, 0x5B40,
    0x9901, 0x59C0, 0x5880, 0x9841, 0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1,
    0x8A81, 0x4A40, 0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
    0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641, 0x8201, 0x42C0,
    0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};

/**
 * @brief Calculates the CRC-16 (Modbus) checksum for a given buffer.
 * @param buffer: Pointer to the data buffer.
 * @param len: Length of the data buffer.
 * @return The calculated CRC-16 value.
 */
static uint16_t calculate_crc16(uint8_t *buffer, uint16_t len) {
    uint16_t crc = 0xFFFF;
    for (uint16_t pos = 0; pos < len; pos++) {
        crc = (crc >> 8) ^ crc16_table[(crc ^ buffer[pos]) & 0xFF];
    }
    return crc;
}

/**
 * @brief Builds a Modbus RTU Read Holding Registers request frame.
 * @param tx_buffer: Buffer to store the generated request frame.
 * @param slave_id: Slave address of the device to poll.
 * @param function_code: The Modbus function code (e.g., 0x03).
 * @param start_addr: Starting register address to read.
 * @param num_regs: Number of registers to read.
 * @return The total length of the generated frame (including CRC).
 */
static uint8_t Modbus_build_request(uint8_t* tx_buffer, uint8_t slave_id,
                                    uint8_t function_code, uint16_t start_addr, uint16_t num_regs) {
    // 💡 CHANGE: Modbus requests use 0-based addresses. The meter manual
    // uses 1-based, so we subtract 1 here.
    uint16_t modbus_addr = start_addr - 1;

    tx_buffer[0] = slave_id;
    tx_buffer[1] = function_code;
    tx_buffer[2] = (modbus_addr >> 8) & 0xFF;
    tx_buffer[3] = modbus_addr & 0xFF;
    tx_buffer[4] = (num_regs >> 8) & 0xFF;
    tx_buffer[5] = num_regs & 0xFF;

    uint16_t crc = calculate_crc16(tx_buffer, 6);
    tx_buffer[6] = crc & 0xFF; // CRC LSB
    tx_buffer[7] = (crc >> 8) & 0xFF; // CRC MSB
    printf("Modbus buffer set cmpt \r\n");
    return 8; // Total frame length
}

/**
 * @brief Parses a Modbus response and extracts a 32-bit float value.
 * @param rx_buffer: Received Modbus response buffer.
 * @param slave_id: Expected slave ID.
 * @param function_code: Expected function code.
 * @return The parsed float value, or NAN on error.
 */
static float Modbus_parse_response_float(uint8_t* rx_buffer,
                                         uint8_t slave_id, uint8_t function_code) {

    // 💡 ADDED: Debug prints to show raw received data
    printf("Raw RX: %02X %02X %02X %02X %02X %02X %02X %02X %02X\r\n",
           rx_buffer[0], rx_buffer[1], rx_buffer[2], rx_buffer[3], rx_buffer[4],
           rx_buffer[5], rx_buffer[6], rx_buffer[7], rx_buffer[8]);

    // --- Validate response header ---
    if (rx_buffer[0] != slave_id) {
        printf("❌ ERROR: Slave ID mismatch. Expected %d, got %d\r\n", slave_id, rx_buffer[0]);
        return NAN;
    }
    if (rx_buffer[1] != function_code) {
        // Check for a Modbus exception response
        if ((rx_buffer[1] & 0x80) == 0x80) {
            printf("❌ ERROR: Modbus Exception! Code 0x%02X\r\n", rx_buffer[2]);
        }
        printf("❌ ERROR: Function code mismatch. Expected 0x%02X, got 0x%02X\r\n", function_code, rx_buffer[1]);
        return NAN;
    }
    if (rx_buffer[2] != 4) { // 2 registers * 2 bytes/register = 4 bytes
        printf("❌ ERROR: Unexpected byte count. Expected 4, got %d\r\n", rx_buffer[2]);
        return NAN;
    }

    // --- Validate CRC ---
    uint16_t calculated_crc = calculate_crc16(rx_buffer, 7); // Calculate CRC over the first 7 bytes
    uint16_t received_crc = (uint16_t)(rx_buffer[8] << 8) | rx_buffer[7];
    if (received_crc != calculated_crc) {
        printf("❌ ERROR: CRC mismatch. Calculated 0x%04X, got 0x%04X\r\n", calculated_crc, received_crc);
        return NAN;
    }
    printf("✅ CRC check passed.\r\n"); // 💡 ADDED: Debug print

    // --- Correctly parse the 32-bit float value ---
    float_converter_t converter;

    // 💡 FIX: The Enersol MFR28 uses a word-swapped, big-endian byte order.
    // We must re-order the bytes accordingly.
    // The received bytes are: [D3] [D2] [D1] [D0]
    // The correct float representation is: [D1] [D0] [D3] [D2]
    converter.u8[0] = rx_buffer[4]; // D1
    converter.u8[1] = rx_buffer[3]; // D0
    converter.u8[2] = rx_buffer[6]; // D3
    converter.u8[3] = rx_buffer[5]; // D2

    printf("✅ Success: Parsed float = %.2f\r\n", converter.f); // 💡 ADDED: Debug print
    return converter.f;
}

/**
 * @brief Initializes the Modbus Master Handle.
 */
void Modbus_Master_Init(Modbus_Master_Handle* hmodbus, uint8_t slave_id,
                        UART_HandleTypeDef* huart, GPIO_TypeDef* de_port, uint16_t de_pin) {
    hmodbus->slave_id = slave_id;
    hmodbus->huart = huart;
    hmodbus->de_port = de_port;
    hmodbus->de_pin = de_pin;
    printf("Modbus Master Initialized with Slave ID: %d\r\n", hmodbus->slave_id);
}

/**
 * @brief Reads a 32-bit float value from the Modbus slave.
 * @param hmodbus: Pointer to the Modbus Master Handle.
 * @param reg_addr: 1-based register address to read.
 * @param result: Pointer to the float variable to store the result.
 * @return HAL_OK on success, otherwise HAL_ERROR or HAL_TIMEOUT.
 */
HAL_StatusTypeDef Modbus_Master_Read_Float(Modbus_Master_Handle* hmodbus,
                                           uint16_t reg_addr, float* result) {
    // We need to request 2 registers for a 32-bit float.
    uint8_t frame_len = Modbus_build_request(hmodbus->tx_buffer, hmodbus->slave_id,
                                             MODBUS_FC_READ_HOLDING_REGISTERS, reg_addr, 2);

    // 💡 FIX: Add a small delay before toggling DE high.
    // Toggling DE right before Transmit can be too fast.

   // HAL_Delay(1000);

    // Enable the RS-485 transceiver for transmission



    // 💡 FIX: Wait for the transceiver to be ready
    // A small delay allows the transceiver to settle before sending data.
    //HAL_Delay(1000);

//     Transmit the Modbus request over UART
//    if (HAL_UART_Transmit(hmodbus->huart, hmodbus->tx_buffer, frame_len, 1000) != HAL_OK) {
//        printf("❌ ERROR: UART Transmit failed for register 0x%04X\r\n", reg_addr);
//        HAL_GPIO_WritePin(hmodbus->de_port, hmodbus->de_pin, 0);
//        return HAL_ERROR;
//    }

    // 💡 FIX: Wait for the transmission to complete before disabling DE.
    // The Transmit function is non-blocking, so we need to wait for the
    // transmission to finish before we disable the driver.
    while(HAL_UART_GetState(hmodbus->huart) == HAL_UART_STATE_BUSY_TX);

    // Disable the RS-485 transceiver (switch to receive mode)
    HAL_GPIO_WritePin(hmodbus->de_port, hmodbus->de_pin, GPIO_PIN_RESET);
   // printf("Hello\n");

    // Clear the receive buffer to avoid stale data
    memset(hmodbus->rx_buffer, 0, 9);

    // Wait for the Modbus response (9 bytes expected: SlaveID, FC, ByteCount, 4 data bytes, 2 CRC bytes)
    if (HAL_UART_Receive(hmodbus->huart, hmodbus->rx_buffer, 9, 300) != HAL_OK) {
        printf("❌ ERROR: UART Receive timeout for register 0x%04X\r\n", reg_addr);
        return HAL_TIMEOUT;
    }

    *result = Modbus_parse_response_float(hmodbus->rx_buffer,
                                          hmodbus->slave_id,
                                          MODBUS_FC_READ_HOLDING_REGISTERS);

    if (isnan(*result)) {
        printf("❌ ERROR: Failed to parse float from response for register 0x%04X\r\n", reg_addr);
        return HAL_ERROR;
    }

    return HAL_OK;
}
