// Backend: reads serial lines and parses meter diagnostic output (the format you pasted from PuTTY)
const express = require('express');
const cors = require('cors');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const app = express();
const PORT = process.env.PORT || 8000;
const SERIAL_PORT = process.env.SERIAL_PORT || 'COM5';
const SERIAL_BAUD = parseInt(process.env.SERIAL_BAUD || '9600', 10);

app.use(cors());
app.use(express.json());

// meters store: meterId -> array newest-first
const meters = new Map();
function ensureMeter(id){ if(!meters.has(id)) meters.set(id, []); }

// mapping from register numbers (as seen in your output) to friendly keys
const regMap = {
  3863: { key: 'voltage', desc: 'Phase Voltage (V)' },
  3864: { key: 'voltage', desc: 'Phase Voltage (V)' },
  3865: { key: 'voltage', desc: 'Phase Voltage (V)' },
  3866: { key: 'voltage', desc: 'Phase Voltage (V)' },
  3854: { key: 'frequency', desc: 'Frequency (Hz)' },
  3848: { key: 'line_to_line', desc: 'Line-to-Line (V)', scale: 1.5 },
  3850: { key: 'line_to_neutral', desc: 'Line-to-Neutral (V)', scale: 3.0 }
};

// Start serial port
function startSerial(){
  try{
    const port = new SerialPort({ path: SERIAL_PORT, baudRate: SERIAL_BAUD, autoOpen: false });
    const parser = port.pipe(new ReadlineParser({ delimiter: '\n', trim: true }));
    port.open(err=>{ if(err) console.error('failed to open', err.message); else console.log('serial open', SERIAL_PORT, SERIAL_BAUD); });
    parser.on('data', line=>{
      if(!line) return;
      console.log('[serial raw]', line);
      // Your lines include patterns like: "Reg 3863 : regs 0x999A 0x4364 -> float swapped: 228.600006, uint32 swapped: 1130666394"
      // We'll attempt to extract reg number and the "float swapped" value.
      const regMatch = line.match(/Reg\s+(\d+)\s*[:|].*?float swapped:\s*([+-]?\d+\.?\d*(?:[eE][+-]?\d+)?)/i);
      if(regMatch){
        const reg = Number(regMatch[1]);
        const val = Number(regMatch[2]);
        const mapping = regMap[reg];
        const now = new Date().toISOString();
        // default meter id 1 (your output used slave1)
        const meterId = '1';
        ensureMeter(meterId);
        const entry = { timestamp: now };
        if(mapping){
          const v = mapping.scale ? +(val * mapping.scale).toFixed(6) : +(val).toFixed(6);
          entry[mapping.key] = v;
        } else {
          // unknown reg, store by reg_{num}
          entry[`reg_${reg}`] = +val.toFixed(6);
        }
        // merge with last reading if within 2 seconds to avoid many single-field entries
        const arr = meters.get(meterId);
        if(arr.length && (new Date(arr[0].timestamp).getTime() + 2000) > Date.now()){
          // merge into latest object
          Object.assign(arr[0], entry);
        } else {
          arr.unshift(entry); // newest first
        }
        // keep bounded
        if(arr.length > 2000) arr.pop();
        console.log('[parsed]', entry);
        return;
      }

      // fallback: try to extract numbers like "R-phase Voltage (reg3866): 228.600 V   (raw u32=1130666394)"
      const altMatch = line.match(/([A-Za-z\-\s]+)\(reg(\d+)\):\s*([+-]?\d+\.?\d*)\s*V/i);
      if(altMatch){
        const reg = Number(altMatch[2]);
        const val = Number(altMatch[3]);
        const mapping = regMap[reg] || { key: 'voltage' };
        const meterId='1'; ensureMeter(meterId);
        const entry = { timestamp: new Date().toISOString() };
        entry[mapping.key] = +val;
        const arr = meters.get(meterId);
        if(arr.length && (new Date(arr[0].timestamp).getTime() + 2000) > Date.now()){
          Object.assign(arr[0], entry);
        } else arr.unshift(entry);
        console.log('[parsed-alt]', entry);
        return;
      }

      // nothing matched
    });
    port.on('error', err=>console.error('serial error', err.message));
  }catch(err){
    console.error('startSerial failed', err.message);
  }
}

startSerial();

// API: return newest-first array
app.get('/api/meters/:id/readings', (req,res)=>{
  const id = String(req.params.id || '1');
  ensureMeter(id);
  const limit = Math.max(1, Math.min(1000, parseInt(req.query.limit||'120',10)));
  const arr = meters.get(id) || [];
  res.json(arr.slice(0,limit));
});

app.get('/api/health', (req,res)=> res.json({status:'ok', time: new Date().toISOString()}));

app.listen(PORT, ()=> console.log(`server http://localhost:${PORT}   serial:${SERIAL_PORT}@${SERIAL_BAUD}`));
