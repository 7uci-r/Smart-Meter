Smart-meter backend (serial parser)

Steps:
1. Install: npm install
2. Set env vars in PowerShell and run:
   $env:SERIAL_PORT="COM5"
   $env:SERIAL_BAUD="9600"
   npm start
3. Watch console logs for serial raw lines and parsed entries.
4. Frontend expects API at http://localhost:8000/api/meters/1/readings
