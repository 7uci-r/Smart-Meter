import React from 'react'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts'

export default function MeterChart({data=[], lines=[{key:'voltage'}], height=300}){
  const formatted = data.map(d=>({ ...d, label: new Date(d.timestamp).toLocaleTimeString() }))
  return (
    <div style={{width:'100%', height}}>
      <ResponsiveContainer>
        <LineChart data={formatted} margin={{top:10,right:30,left:0,bottom:0}}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="label" minTickGap={20} />
          <YAxis />
          <Tooltip />
          <Legend />
          {lines.map((l,i)=> <Line key={l.key} type="monotone" dataKey={l.key} name={l.name||l.key} dot={false} />)}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
