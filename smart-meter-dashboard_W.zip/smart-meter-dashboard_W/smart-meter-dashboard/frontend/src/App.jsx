import React, { useEffect, useState, useRef } from 'react'
import MeterChart from './components/MeterChart'
import { fetchMeterReadings } from './api'

export default function App(){
  const [meterId, setMeterId] = useState(1)
  const [poll, setPoll] = useState(true)
  const [intervalMs, setIntervalMs] = useState(5000)
  const [data, setData] = useState([])
  const [error, setError] = useState(null)
  const timerRef = useRef(null)

  async function load(){
    try{
      const res = await fetchMeterReadings(meterId, 120)
      setData(res)
      setError(null)
    }catch(e){
      setError(e.message)
    }
  }

  useEffect(()=>{
    load()
    if(poll){
      timerRef.current = setInterval(load, intervalMs)
    }
    return ()=> clearInterval(timerRef.current)
  }, [meterId, poll, intervalMs])

  const latest = data[0] || {}

  return (
    <div className="app">
      <header className="topbar">
        <h1>Smart Meter — Live Dashboard</h1>
        <div className="controls">
          <label>Meter ID <input type="number" value={meterId} onChange={e=>setMeterId(Number(e.target.value))} min={1} /></label>
          <label>Poll ms <input type="number" value={intervalMs} onChange={e=>setIntervalMs(Number(e.target.value))} /></label>
          <button onClick={()=>setPoll(p=>!p)}>{poll?'Stop':'Start'}</button>
          <button onClick={load}>Refresh</button>
        </div>
      </header>

      <main>
        {error && <div className="error">Error: {error}</div>}

        <section className="cards">
          <div className="card">
            <h3>Voltage (V)</h3>
            <div className="big">{latest.voltage ?? '—'}</div>
            <div className="muted">Phase R</div>
          </div>
          <div className="card">
            <h3>Frequency (Hz)</h3>
            <div className="big">{latest.frequency ?? '—'}</div>
            <div className="muted">f</div>
          </div>
          <div className="card">
            <h3>Line-to-Line (V)</h3>
            <div className="big">{latest.line_to_line ?? '—'}</div>
            <div className="muted">diag ×1.5</div>
          </div>
        </section>

        <section className="chart-area">
          <MeterChart data={data} lines={[{key:'voltage', name:'Voltage (V)'},{key:'frequency', name:'Freq (Hz)'}]} height={320} />
        </section>

        <section className="table-area">
          <h3>Latest readings (most recent first)</h3>
          <table>
            <thead><tr><th>Time</th><th>Voltage</th><th>Freq</th><th>Line-to-Line</th></tr></thead>
            <tbody>
              {data.slice(0,20).map((r,i)=>(
                <tr key={i}>
                  <td>{new Date(r.timestamp).toLocaleString()}</td>
                  <td>{r.voltage ?? '-'}</td>
                  <td>{r.frequency ?? '-'}</td>
                  <td>{r.line_to_line ?? '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </main>

      <footer className="footer">Backend API: <code>/api/meters/:id/readings?limit=N</code></footer>
    </div>
  )
}
