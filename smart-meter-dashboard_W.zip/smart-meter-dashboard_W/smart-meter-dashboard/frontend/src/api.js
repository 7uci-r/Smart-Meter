export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

export async function fetchMeterReadings(meterId=1, limit=120){
  const url = `${API_BASE}/api/meters/${meterId}/readings?limit=${limit}`
  const res = await fetch(url, {cache:'no-store'})
  if(!res.ok){ const t = await res.text(); throw new Error(`API ${res.status}: ${t}`) }
  return res.json()
}
