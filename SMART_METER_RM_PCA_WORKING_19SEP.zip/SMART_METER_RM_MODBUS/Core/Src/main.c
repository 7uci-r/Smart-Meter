/* main.c
 *
 * Single-phase focused Modbus poller for Enersol MFR series (minimal prints)
 *
 * Integrated: PCA-style data pruning on a 60×3 batch (Current, Voltage, Frequency).
 * - Collects 60 samples at 1 Hz
 * - Computes column means, 3x3 covariance
 * - Runs a small Jacobi eigensolver for the symmetric 3×3 covariance
 * - Projects to top-k principal components (k configurable)
 * - Reconstructs, computes MSE and prints savings/variance explained
 *
 * No external DSP library is required (small, self
 * contained math routines).
 */

#include "main.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Use your existing UART handles from CubeMX-generated usart.c */
extern UART_HandleTypeDef huart2; /* Modbus (USART2) */
extern UART_HandleTypeDef huart3; /* Debug (USART3) */

/* Route printf to huart3 (debug) */
#ifdef __GNUC__
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif
PUTCHAR_PROTOTYPE {
    HAL_UART_Transmit(&huart3, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

/* Prototypes */
void SystemClock_Config(void);
void Error_Handler(void);

/* RS485 DE pin */
#define RS485_DE_PORT  GPIOA
#define RS485_DE_PIN   GPIO_PIN_4

/* Modbus settings */
#define MODBUS_SLAVE_ID  1

/* Sweep delay between overall sweeps (ms) */
#define SWEEP_DELAY_MS 2000U

/* PCA batch size and dims */
#define BATCH_M 60
#define N_VARS 3

/* Choose how many principal components to keep when reporting/compressing */
#define KEEP_K 1 /* change to 2 to keep two components */

/* Register IDs used for sampling (current, voltage, frequency) */
#define REG_CURRENT 3852
#define REG_VOLTAGE 3866
#define REG_FREQ    3854

/* CRC16 (Modbus) */
static uint16_t Modbus_CRC16(const uint8_t *buf, uint16_t len) {
    uint16_t crc = 0xFFFF;
    for (uint16_t pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (uint8_t i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

/* Print hex buffer on debug UART */
static void print_hex_buf(const uint8_t *buf, uint16_t len) {
    for (uint16_t i = 0; i < len; ++i) printf("%02X ", buf[i]);
    printf("\r\n");
}

/* low-level: send a Modbus request (function 0x03 or 0x04), read response (blocking)
   returns 0 on success and places 'byteCount' payload into payload and sets *payload_len */
static int modbus_txrx(uint8_t slaveID, uint8_t functionCode, uint16_t startAddr, uint16_t numRegs,
                       uint8_t *payload, uint16_t *payload_len)
{
    uint8_t tx[8];
    tx[0] = slaveID;
    tx[1] = functionCode;
    tx[2] = (uint8_t)(startAddr >> 8);
    tx[3] = (uint8_t)(startAddr & 0xFF);
    tx[4] = (uint8_t)(numRegs >> 8);
    tx[5] = (uint8_t)(numRegs & 0xFF);
    uint16_t crc = Modbus_CRC16(tx, 6);
    tx[6] = crc & 0xFF;
    tx[7] = (crc >> 8) & 0xFF;

    /* Set DE = TX */
    HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_SET);
    HAL_Delay(1);

    if (HAL_UART_Transmit(&huart2, tx, 8, HAL_MAX_DELAY) != HAL_OK) {
        HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_RESET);
        return -1;
    }

    HAL_Delay(2);
    HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_RESET);

    /* read first 3 bytes of response (addr, func, bytecount) */
    uint8_t hdr[3];
    if (HAL_UART_Receive(&huart2, hdr, 3, 500) != HAL_OK) return -2;
    uint8_t byteCount = hdr[2];
    uint16_t remaining = (uint16_t)byteCount + 2; /* data + CRC */
    uint16_t total = 3 + remaining;
    if (total > 128) return -3;

    uint8_t rx[128];
    rx[0] = hdr[0]; rx[1] = hdr[1]; rx[2] = hdr[2];
    if (HAL_UART_Receive(&huart2, &rx[3], remaining, 500) != HAL_OK) return -4;

    /* Verify CRC */
    uint16_t rxCrc = (uint16_t)rx[total-2] | ((uint16_t)rx[total-1] << 8);
    uint16_t calc = Modbus_CRC16(rx, total - 2);
    if (rxCrc != calc) {
        printf("CRC mismatch (calc %04X rx %04X)\r\n", calc, rxCrc);
        return -5;
    }

    /* Print the raw frame for trace (kept for debugging) */
    printf("RAW RX (slave%u reg%u func%02X): ", (unsigned)slaveID, (unsigned)startAddr, (unsigned)functionCode);
    print_hex_buf(rx, total);

    /* copy payload bytes (data only) */
    if (payload && payload_len) {
        if (byteCount > *payload_len) return -6;
        memcpy(payload, &rx[3], byteCount);
        *payload_len = byteCount;
    }
    return 0;
}

/* wrapper: try function 0x03 first, then 0x04 */
static int modbus_read_try03_04(uint8_t slaveID, uint16_t startAddr, uint16_t numRegs,
                                uint8_t *payload, uint16_t *payload_len)
{
    uint16_t len = *payload_len;
    int rc = modbus_txrx(slaveID, 0x03, startAddr, numRegs, payload, &len);
    if (rc == 0) { *payload_len = len; return 0; }
    len = *payload_len;
    rc = modbus_txrx(slaveID, 0x04, startAddr, numRegs, payload, &len);
    if (rc == 0) { *payload_len = len; return 0; }
    return rc;
}

/* Interpret two 16-bit regs (big-endian words) as word-swapped 32-bit float and uint32 */
static void regs_to_swapped_float_u32(const uint8_t *payload, float *out_f, uint32_t *out_u32)
{
    uint16_t regHi = (uint16_t)payload[0] << 8 | payload[1];
    uint16_t regLo = (uint16_t)payload[2] << 8 | payload[3];
    uint32_t swapped = ((uint32_t)regLo << 16) | regHi;
    if (out_u32) *out_u32 = swapped;
    if (out_f) {
        float f; memcpy(&f, &swapped, sizeof(f)); *out_f = f;
    }
}

/* Read 2 regs and return swapped float/u32 (0 on success) */
static int read_pair_ws(uint16_t reg, float *out_f, uint32_t *out_u32)
{
    uint8_t payload[8]; uint16_t payload_len = sizeof(payload);
    int rc = modbus_read_try03_04(MODBUS_SLAVE_ID, reg, 2, payload, &payload_len);
    if (rc != 0) return rc;
    if (payload_len < 4) return -2;
    regs_to_swapped_float_u32(payload, out_f, out_u32);
    return 0;
}

/* ---------------- PCA helper routines (small, self-contained) ---------------- */

/* Compute column means for an m×n matrix */
static void compute_means(const float data[BATCH_M][N_VARS], size_t m, float mean[N_VARS]) {
    for (size_t j = 0; j < N_VARS; ++j) mean[j] = 0.0f;
    for (size_t i = 0; i < m; ++i)
        for (size_t j = 0; j < N_VARS; ++j)
            mean[j] += data[i][j];
    for (size_t j = 0; j < N_VARS; ++j) mean[j] /= (float)m;
}

/* Subtract mean in-place (center the data) */
static void center_data_inplace(float data[BATCH_M][N_VARS], size_t m, const float mean[N_VARS]) {
    for (size_t i = 0; i < m; ++i)
        for (size_t j = 0; j < N_VARS; ++j)
            data[i][j] -= mean[j];
}

/* Compute symmetric 3x3 sample covariance: C = (1/(m-1)) X^T X (X is already centered) */
static void compute_covariance_3x3(const float data[BATCH_M][N_VARS], size_t m, float C[3][3]) {
    /* zero */
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) C[i][j] = 0.0f;
    for (size_t r = 0; r < m; ++r) {
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                C[i][j] += data[r][i] * data[r][j];
    }
    float scale = 1.0f / (float)(m - 1);
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            C[i][j] *= scale;
}

/* Jacobi eigenvalue algorithm for symmetric 3x3
   Outputs:
     - V as 3x3 matrix where columns are eigenvectors
     - d as eigenvalues (unordered)
   Returns number of iterations used (for debugging) */
static int jacobi_eigen_3x3(float A_in[3][3], float V_out[3][3], float d_out[3]) {
    float A[3][3];
    /* copy A_in to local A */
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) A[i][j] = A_in[i][j];
    /* initialize V as identity */
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) V_out[i][j] = (i == j) ? 1.0f : 0.0f;

    const int MAX_IT = 50;
    const float EPS = 1e-6f;
    for (int it = 0; it < MAX_IT; ++it) {
        /* find largest off-diagonal element */
        int p = 0, q = 1;
        float max = fabsf(A[0][1]);
        if (fabsf(A[0][2]) > max) { max = fabsf(A[0][2]); p = 0; q = 2; }
        if (fabsf(A[1][2]) > max) { max = fabsf(A[1][2]); p = 1; q = 2; }
        if (max < EPS) break; /* converged */

        float app = A[p][p];
        float aqq = A[q][q];
        float apq = A[p][q];
        float phi = 0.5f * atan2f(2.0f * apq, (aqq - app));
        float c = cosf(phi);
        float s = sinf(phi);

        /* rotate A: we'll update rows/cols p and q */
        float app_new = c*c*app - 2.0f*s*c*apq + s*s*aqq;
        float aqq_new = s*s*app + 2.0f*s*c*apq + c*c*aqq;

        /* off-diagonal pq becomes zero */
        A[p][q] = A[q][p] = 0.0f;

        /* update the other elements */
        for (int r = 0; r < 3; ++r) {
            if (r == p || r == q) continue;
            float arp = A[r][p];
            float arq = A[r][q];
            A[r][p] = A[p][r] = c*arp - s*arq;
            A[r][q] = A[q][r] = s*arp + c*arq;
        }
        A[p][p] = app_new;
        A[q][q] = aqq_new;

        /* update eigenvector matrix V_out (columns p and q) */
        for (int r = 0; r < 3; ++r) {
            float vip = V_out[r][p];
            float viq = V_out[r][q];
            V_out[r][p] = c*vip - s*viq;
            V_out[r][q] = s*vip + c*viq;
        }
    }
    /* eigenvalues on diagonal now */
    for (int i = 0; i < 3; ++i) d_out[i] = A[i][i];
    return 0;
}

/* sort eigenpairs descending by eigenvalue (in-place) */
static void sort_eigenpairs_desc(float d[3], float V[3][3]) {
    for (int i = 0; i < 3 - 1; ++i) {
        int maxidx = i;
        for (int j = i + 1; j < 3; ++j) if (d[j] > d[maxidx]) maxidx = j;
        if (maxidx != i) {
            float td = d[i]; d[i] = d[maxidx]; d[maxidx] = td;
            for (int r = 0; r < 3; ++r) {
                float tv = V[r][i]; V[r][i] = V[r][maxidx]; V[r][maxidx] = tv;
            }
        }
    }
}

/* Project centered data (m×3) onto first k eigenvectors: Y = Xc * V_k  (result m×k) */
static void project_to_k(const float data[BATCH_M][N_VARS], size_t m, const float V[3][3], int k, float Y[BATCH_M][KEEP_K]) {
    for (size_t i = 0; i < m; ++i) {
        for (int comp = 0; comp < k; ++comp) {
            float acc = 0.0f;
            for (int j = 0; j < 3; ++j) acc += data[i][j] * V[j][comp];
            Y[i][comp] = acc;
        }
    }
}

/* Reconstruct: Xhat = Y * V_k^T + mean
   Xhat is m×3, Y is m×k, V columns are eigenvectors */
static void reconstruct_from_k(const float Y[BATCH_M][KEEP_K], size_t m, const float V[3][3], int k, const float mean[3], float Xhat[BATCH_M][3]) {
    for (size_t i = 0; i < m; ++i) {
        for (int j = 0; j < 3; ++j) {
            float acc = 0.0f;
            for (int comp = 0; comp < k; ++comp) acc += Y[i][comp] * V[j][comp];
            Xhat[i][j] = acc + mean[j];
        }
    }
}

/* Compute MSE across all entries between data(m×3) and Xhat(m×3) */
static float compute_mse(const float data[BATCH_M][3], const float Xhat[BATCH_M][3], size_t m) {
    double s = 0.0;
    for (size_t i = 0; i < m; ++i)
        for (int j = 0; j < 3; ++j) {
            double e = (double)data[i][j] - (double)Xhat[i][j];
            s += e*e;
        }
    return (float)(s / (double)(m * 3));
}

/* ---------------- PCA run: collect 60 samples, compute PCA, print results ---------------- */
static void run_pca_batch(void) {
    static float raw[BATCH_M][N_VARS]; /* order: [current, voltage, frequency] */
    float mean[N_VARS];
    float cov[3][3];
    float V[3][3];
    float eig[3];
    float Y_k1[BATCH_M][KEEP_K];
    float Xhat[BATCH_M][3];

    printf("\r\n--- Starting 60-s PCA batch collection ---\r\n");

    float last_good[N_VARS] = {10.0f, 230.0f, 50.0f};
    for (size_t i = 0; i < BATCH_M; ++i) {
        float cur = 0.0f, volt = 0.0f, freq = 0.0f; uint32_t u;
        int ok1 = (read_pair_ws(REG_CURRENT, &cur, &u) == 0);
        int ok2 = (read_pair_ws(REG_VOLTAGE, &volt, &u) == 0);
        int ok3 = (read_pair_ws(REG_FREQ, &freq, &u) == 0);
        if (!ok1) cur = last_good[0]; else last_good[0] = cur;
        if (!ok2) volt = last_good[1]; else last_good[1] = volt;
        if (!ok3) freq = last_good[2]; else last_good[2] = freq;

        raw[i][0] = cur; raw[i][1] = volt; raw[i][2] = freq;
        printf("[%02u] C=%6.3f A  V=%7.3f V  F=%6.3f Hz\r\n", (unsigned)i+1, (double)cur, (double)volt, (double)freq);
        /* wait approximately 1 second between samples */
        HAL_Delay(1000);
    }

    /* Compute means */
    compute_means(raw, BATCH_M, mean);
    printf("Batch means: Current=%6.3f A  Voltage=%7.3f V  Freq=%6.3f Hz\r\n", (double)mean[0], (double)mean[1], (double)mean[2]);

    /* center data in-place */
    static float centered[BATCH_M][N_VARS];
    for (size_t i = 0; i < BATCH_M; ++i) for (int j = 0; j < N_VARS; ++j) centered[i][j] = raw[i][j] - mean[j];

    /* covariance */
    compute_covariance_3x3(centered, BATCH_M, cov);
    printf("Covariance matrix:\r\n");
    for (int i = 0; i < 3; ++i) printf("  %10.6f  %10.6f  %10.6f\r\n", (double)cov[i][0], (double)cov[i][1], (double)cov[i][2]);

    /* eigen decomposition (Jacobi) */
    jacobi_eigen_3x3(cov, V, eig);
    /* sort eigenpairs descending */
    sort_eigenpairs_desc(eig, V);

    double eigsum = eig[0] + eig[1] + eig[2];
    printf("Eigenvalues (descending): %10.6f  %10.6f  %10.6f\r\n", eig[0], eig[1], eig[2]);
    printf("Explained variance ratios: %6.3f  %6.3f  %6.3f\r\n", eig[0]/eigsum, eig[1]/eigsum, eig[2]/eigsum);

    /* Project to k (KEEP_K) */
    project_to_k(centered, BATCH_M, V, KEEP_K, Y_k1);

    /* Reconstruct from k */
    reconstruct_from_k(Y_k1, BATCH_M, V, KEEP_K, mean, Xhat);

    /* Compute MSE */
    float mse = compute_mse(raw, Xhat, BATCH_M);
    printf("Reconstruction MSE (k=%d): %g\r\n", KEEP_K, (double)mse);

    /* Show savings estimate: raw_bytes vs compressed_bytes when eigenvectors are shared/known
       raw_bytes = m*n*4; compressed per-batch = m*k*4 + n*4 (means). If eigenvectors must be
       sent per-batch add n*k*4. */
    size_t raw_bytes = BATCH_M * N_VARS * sizeof(float);
    size_t compressed_bytes = BATCH_M * KEEP_K * sizeof(float) + N_VARS * sizeof(float); /* means + coeffs */
    double saved = 100.0 * (1.0 - ((double)compressed_bytes / (double)raw_bytes));
    printf("Raw bytes per batch: %u  Compressed bytes (per-batch, w/o eigenvecs): %u  Savings: %5.2f%%\r\n",
           (unsigned)raw_bytes, (unsigned)compressed_bytes, saved);

    /* Print a small table: first 10 rows original vs reconstructed (k components) */
    printf("\r\nSample |   Current   |   Voltage    |   Freq   ||  Curr_hat  Volt_hat  Freq_hat\r\n");
    printf("--------------------------------------------------------------------------\r\n");
    for (size_t i = 0; i < 10 && i < BATCH_M; ++i) {
        printf("%3u    | %9.3f A | %9.3f V | %7.3f Hz || %9.3f %9.3f %9.3f\r\n",
               (unsigned)i+1,
               (double)raw[i][0], (double)raw[i][1], (double)raw[i][2],
               (double)Xhat[i][0], (double)Xhat[i][1], (double)Xhat[i][2]);
    }
    printf("--- End PCA batch ---\r\n");
}

/* ------------------------
   Your existing register list and main() content below — kept intact, minimal edits.
   We call run_pca_batch() at the end of each sweep so you get a 60-second PCA batch
   following the usual single-phase prints.
   ------------------------ */

/* ---------------------------
   REG LIST — SINGLE-PHASE / AVERAGE / ENERGY (VISIBLE PRINTS)
   --------------------------- */
static const uint16_t single_phase_regs[] = {
    3866, /* R-phase Voltage (VLN_r) */
    3854, /* Frequency (Hz) */
    3848, /* LL diagnostic (×1.5 -> ~phase V) */
    3850, /* LN diagnostic (×3.0 -> ~phase V) */
    3852, /* Avg Current (A) — you confirmed this prints well */
    3840, /* Apparent Power (VA, avg) */
    3842, /* Active Power (W, avg) */
    3846, /* Power Factor (avg) */
    3898, /* Forward Apparent Energy (VAh) */
    3900, /* Forward Active Energy (Wh) */
    3902  /* Forward Reactive Energy (VARh) */
};
static const size_t n_single = sizeof(single_phase_regs)/sizeof(single_phase_regs[0]);

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* Initialize peripherals (CubeMX generated functions) */
    MX_GPIO_Init();
    MX_USB_OTG_FS_PCD_Init();
    MX_USART3_UART_Init(); /* debug */
    MX_USART2_UART_Init(); /* modbus */

    /* Ensure DE low (receive) initially */
    HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_RESET);

    printf("\r\nSmartmeter single-phase minimal poller (with PCA batch)\r\n");

    while (1) {
        printf("\r\n=== Single-phase / Average / Energy (clean view) ===\r\n");

        for (size_t i = 0; i < n_single; ++i) {
            uint16_t r = single_phase_regs[i];
            float f = 0.0f; uint32_t u = 0;
            int ok = (read_pair_ws(r, &f, &u) == 0);

            if (r == 3866) {
                if (ok) printf("R-phase Voltage (reg%u): %7.3f V   (raw u32=%lu)\r\n", r, (double)f, (unsigned long)u);
                else    printf("R-phase Voltage (reg%u): read fail\r\n", r);
            } else if (r == 3854) {
                if (ok) printf("Frequency (reg%u):      %7.3f Hz  (raw u32=%lu)\r\n", r, (double)f, (unsigned long)u);
                else    printf("Frequency (reg%u): read fail\r\n", r);
            } else if (r == 3848) {
                if (ok) printf("Line-to-Line (reg%u):   %7.3f  (diag ×1.5 => %7.3f V)\r\n", r, (double)f, (double)(f*1.5f));
                else    printf("Line-to-Line (reg%u): read fail\r\n", r);
            } else if (r == 3850) {
                if (ok) printf("Line-to-Neutral (reg%u):%7.3f  (diag ×3.0 => %7.3f V)\r\n", r, (double)f, (double)(f*3.0f));
                else    printf("Line-to-Neutral (reg%u): read fail\r\n", r);
            } else if (r == 3852) {
                if (ok) printf("Avg Current (reg%u):    %7.3f A\r\n", r, (double)f);
                else    printf("Avg Current (reg%u): read fail\r\n", r);
            }
            /* ===== NEW: POWER & PF ===== */
            else if (r == 3840) {
                if (ok) printf("Apparent Power (reg%u): %7.3f VA\r\n", r, (double)f);
                else    printf("Apparent Power (reg%u): read fail\r\n", r);
            } else if (r == 3842) {
                if (ok) printf("Active Power (reg%u):   %7.3f W\r\n", r, (double)f);
                else    printf("Active Power (reg%u): read fail\r\n", r);
            } else if (r == 3846) {
                if (ok) printf("Power Factor (reg%u):   %7.3f\r\n", r, (double)f);
                else    printf("Power Factor (reg%u): read fail\r\n", r);
            }
            /* ===== NEW: ENERGIES ===== */
            else if (r == 3898) {
                if (ok) printf("Forward VAh (reg%u):    %7.3f VAh\r\n", r, (double)f);
                else    printf("Forward VAh (reg%u): read fail\r\n", r);
            } else if (r == 3900) {
                if (ok) printf("Forward Wh (reg%u):     %7.3f Wh\r\n", r, (double)f);
                else    printf("Forward Wh (reg%u): read fail\r\n", r);
            } else if (r == 3902) {
                if (ok) printf("Forward VARh (reg%u):   %7.3f VARh\r\n", r, (double)f);
                else    printf("Forward VARh (reg%u): read fail\r\n", r);
            }
            /* Fallback generic (kept for future regs) */
            else {
                if (ok) {
                    uint16_t w0 = ((uint16_t)(u & 0xFFFF));
                    uint16_t w1 = (uint16_t)(u >> 16);
                    printf("Reg %u : words 0x%04X 0x%04X -> float: %f, u32: %lu\r\n",
                           (unsigned)r, (unsigned)w0, (unsigned)w1, (double)f, (unsigned long)u);
                } else {
                    printf("Reg %u : read fail\r\n", (unsigned)r);
                }
            }

            HAL_Delay(60);
        }

        printf("\r\n--- End sweep ---\r\n");

        /* NEW: run PCA batch collection (60 samples at 1 Hz) and print summary */
        run_pca_batch();

        HAL_Delay(SWEEP_DELAY_MS);
    }
}

/* Use your project's SystemClock_Config() and Error_Handler() as before. */
void SystemClock_Config(void)
{
  /* Keep your CubeMX-generated content here (the same as your working build). */
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 384;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK) { Error_Handler(); }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* Optionally print file/line for parameter errors */
}
#endif
